<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to commercial source code license 
 * of StoreFront Consulting, Inc.
 *
 * @package		<Namespace>_<Module>
 * @author		<Author>
 * @copyright	(C)Copyright 2011 StoreFront Consulting, Inc (http://www.StoreFrontConsulting.com/)
 */

class <Namespace>_<Module>_Block_Adminhtml_<Module> extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_<module>';
    $this->_blockGroup = '<module>';
    $this->_headerText = Mage::helper('<module>')->__('Item Manager');
    $this->_addButtonLabel = Mage::helper('<module>')->__('Add Item');
    parent::__construct();
  }
}