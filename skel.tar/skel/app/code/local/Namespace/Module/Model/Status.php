<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to commercial source code license 
 * of StoreFront Consulting, Inc.
 *
 * @package		<Namespace>_<Module>
 * @author		<Author>
 * @copyright	(C)Copyright 2011 StoreFront Consulting, Inc (http://www.StoreFrontConsulting.com/)
 */


class <Namespace>_<Module>_Model_Status extends Varien_Object
{
    const STATUS_ENABLED	= 1;
    const STATUS_DISABLED	= 2;

    static public function getOptionArray()
    {
        return array(
            self::STATUS_ENABLED    => Mage::helper('<module>')->__('Enabled'),
            self::STATUS_DISABLED   => Mage::helper('<module>')->__('Disabled')
        );
    }
}