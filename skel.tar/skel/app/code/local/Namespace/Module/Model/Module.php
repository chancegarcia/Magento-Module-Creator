<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to commercial source code license 
 * of StoreFront Consulting, Inc.
 *
 * @package		<Namespace>_<Module>
 * @author		<Author>
 * @copyright	(C)Copyright 2011 StoreFront Consulting, Inc (http://www.StoreFrontConsulting.com/)
 */


class <Namespace>_<Module>_Model_<Module> extends Mage_Core_Model_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('<module>/<module>');
    }
}