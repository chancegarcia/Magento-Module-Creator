<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to commercial source code license 
 * of StoreFront Consulting, Inc.
 *
 * @package		<Namespace>_<Module>
 * @author		<Author>
 * @copyright	(C)Copyright 2011 StoreFront Consulting, Inc (http://www.StoreFrontConsulting.com/)
 */


class <Namespace>_<Module>_Model_Mysql4_<Module> extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {    
        // Note that the <module>_id refers to the key field in your database table.
        $this->_init('<module>/<module>', '<module>_id');
    }
}