<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to commercial source code license 
 * of StoreFront Consulting, Inc.
 *
 * @package		<Namespace>_<Module>
 * @author		<Author>
 * @copyright	(C)Copyright 2011 StoreFront Consulting, Inc (http://www.StoreFrontConsulting.com/)
 */


class <Namespace>_<Module>_Helper_Data extends Mage_Core_Helper_Abstract
{

}