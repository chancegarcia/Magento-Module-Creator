********************************
File
  README_<Namespace>_<Module>.txt

Extension
  <Namespace>_<Module>

Developer
  <Author>
  StoreFront Consulting, Inc.
  (C)Copyright 2011.

Description
	

Compatibility
  Magento CE 1.4.x

Installation
  1. Install contents of this .ZIP package into Magento base folder.
  2. 
  3. Clear all cache and sessions.


